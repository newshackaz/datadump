"Police Use of Nonfatal Force, 2002-11      NCJ 249216"			
			
This zip archive contains tables in individual  .csv spreadsheets			
"from Police Use of Nonfatal Force, 2002-11, NCJ 249216.  The full report including text"			
and graphics in pdf format is available from:http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5456			
			
			
Filename			 Table title
punf0211t01.csv			"Table 1. Police�resident contact and contact involving threat or use of force, by demographic characteristics, 2002�11"
punf0211t02.csv			"Table 2. Police contact with and without threat or use of force, by race or Hispanic origin of resident, 2002�11"
punf0211t03.csv			"Table 3. Police contacts involving threat or use of force, by type of contact and race or Hispanic origin of resident, 2002�11"
punf0211t04.csv			"Table 4. Perceptions that police threatened or used excessive force, by type of force and race or Hispanic origin of resident, 2002�11"
punf0211t05.csv			"Table 5. Perceptions that police behaved properly during all contact, by race or Hispanic origin of resident, 2002�11"
punf0211t06.csv			"Table 6. Residents with police contact who experienced threat or use of force, by race and Hispanic origin and number of contacts, 2005�11"
punf0211t07.csv			"Table 7. Traffic stops and traffic stops involving threat or use of force, by race of officer and driver, 2002�11"
punf0211t08.csv			"Table 8. Residents with police contact who experienced a personal search, with and without threat or use of force, 2002�11"
punf0211t09.csv			"Table 9. Prevalence of use of force during police contact, 2002�11"

Appendix tables			
punf0211at01.csv		"Appendix table 1. Estimates and standard errors for figure 1: Residents with police contact who experienced threat or use of force, by race or Hispanic origin, 2002�11"
punf0211at02.csv		"Appendix table 2. Standard errors for table 1: Police contact with and without threat or use of force, by demographic characteristics, 2002�11"
punf0211at03.csv		"Appendix table 3. Standard errors for table 2: Police-resident contact with and without threat or use of force, by race or Hispanic origin of resident, 2002�11"
punf0211at04.csv		"Appendix table 4. Standard errors for table 3: Police contact involving threat or use of force, by type of contact and race or Hispanic origin of resident, 2002�11"
punf0211at05.csv		"Appendix table 5. Estimates and standard errors for figure 2: Residents with police contact who experienced threat or use of force, 2002, 2005, 2008, and 2011"
punf0211at06.csv		"Appendix table 6. Estimates and standard errors for figure 3: Residents with police contact who experienced threat or use of force, 2002, 2005, 2008, and 2011"
punf0211at07.csv		"Appendix table 7. Estimates and standard errors for figure 4: Residents with police contact who experienced threat or use of force, by type of contact, 2002, 2005, 2008, and 2011"
punf0211at08.csv		"Appendix table 8. Standard errors for table 4: Perceptions that police threat or use of force was excessive, by type of force and race or Hispanic origin of resident, 2002�11"
punf0211at09.csv		"Appendix table 9. Estimates and standard errors for figure 5: Percent of residents who believed police threat or use of force was excessive, by type of force, 2002�11"
punf0211at10.csv		"Appendix table 10. Standard errors for table 5: Perceptions that police behaved properly during all contacts, by race or Hispanic origin of resident, 2002�11"
punf0211at11.csv		"Appendix table 11. Standard errors for table 6: Residents with police contact who experienced threat or use of force, by race or Hispanic origin and number of contacts, 2005�11"
punf0211at12.csv		"Appendix table 12. Standard errors of table 7: Traffic stops with and without threat or use of force, by race of officer and driver, 2002�11"
punf0211at13.csv		"Appendix table 13. Standard errors for table 8: Residents with police contact who experienced a personal search, with and without threat or use of force, 2002�11"

Figure Tables
punf0211f01.csv			"Figure 1. Residents with police contact who experienced threat or use of force, by race or Hispanic origin, 2002�11"
punf0211f02.csv			"Figure 2. Residents with police contact who experienced threat or use of force, 2002, 2005, 2008, and 2011"
punf0211f03.csv			"Figure 3. Residents with police contact who experienced threat or use of force, by race and Hispanic origin, 2002, 2005, 2008, and 2011"
punf0211f04.csv			"Figure 4. Residents with police contact who experienced threat or use of force, by type of contact, 2002, 2005, 2008, and 2011"
punf0211f05.csv			"Figure 5. Percent of residents who believed police threat or use of force was excessive, by type of force, 2002�11"
